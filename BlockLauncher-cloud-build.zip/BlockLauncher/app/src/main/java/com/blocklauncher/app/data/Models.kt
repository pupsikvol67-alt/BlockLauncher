package com.blocklauncher.app.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Ошибка с текстом для пользователя на двух языках. */
class UserMessage(val ru: String, val en: String) : Exception(ru)

enum class ItemKind { ADDON, BEHAVIOR, RESOURCE, WORLD }

data class LibItem(
    val id: String,
    val kind: ItemKind,
    val ext: String,
    val name: String,
    val description: String,
    val hasIcon: Boolean,
    val sizeBytes: Long,
    val addedAt: Long,
    /** Когда файл последний раз передавали в Minecraft (0 — никогда). */
    val sentAt: Long = 0L,
) {
    val fileName get() = "$id.$ext"

    fun toJson(): JSONObject = JSONObject().put("id", id).put("kind", kind.name).put("ext", ext)
        .put("name", name).put("description", description).put("hasIcon", hasIcon)
        .put("size", sizeBytes).put("addedAt", addedAt).put("sentAt", sentAt)

    companion object {
        fun fromJson(o: JSONObject) = LibItem(
            o.getString("id"), ItemKind.valueOf(o.getString("kind")), o.getString("ext"),
            o.optString("name"), o.optString("description"), o.optBoolean("hasIcon"),
            o.optLong("size"), o.optLong("addedAt"), o.optLong("sentAt"),
        )
    }
}

data class BuildPack(
    val id: String,
    val name: String,
    val description: String,
    val hasCover: Boolean,
    val itemIds: List<String>,
    val createdAt: Long,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("description", description)
        .put("hasCover", hasCover).put("items", JSONArray(itemIds)).put("createdAt", createdAt)

    companion object {
        fun fromJson(o: JSONObject): BuildPack {
            val arr = o.optJSONArray("items") ?: JSONArray()
            return BuildPack(
                o.getString("id"), o.optString("name"), o.optString("description"), o.optBoolean("hasCover"),
                (0 until arr.length()).map { arr.getString(it) }, o.optLong("createdAt"),
            )
        }
    }
}

fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)

fun safeName(s: String): String =
    s.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").trim().take(60).ifEmpty { "file" }

object Img {
    /** Декодирует картинку с уменьшением, чтобы не раздувать память. */
    fun decode(bytes: ByteArray, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
    }
}
