package com.blocklauncher.app.ui

import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blocklauncher.app.data.ItemKind
import com.blocklauncher.app.data.WorldEntry
import com.blocklauncher.app.data.safeName
import java.io.File

@Composable
fun WorldsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val lib by vm.items.collectAsStateWithLifecycle()
    val worlds by vm.worlds.collectAsStateWithLifecycle()
    val err by vm.worldsError.collectAsStateWithLifecycle()
    val tree by vm.settings.worldsTree.collectAsStateWithLifecycle()
    val backups by vm.worldBackups.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<WorldEntry?>(null) }
    var toDeleteLib by remember { mutableStateOf<com.blocklauncher.app.data.LibItem?>(null) }
    var toDeleteBackup by remember { mutableStateOf<File?>(null) }

    val export = rememberExporter()
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setWorldsTree) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }

    LaunchedEffect(tree) { vm.refreshWorlds() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { if (tree != null) vm.refreshWorlds() }

    val initial: Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents", "primary:Android/data/com.mojang.minecraftpe/files/games/com.mojang",
    )
    val libWorlds = lib.filter { it.kind == ItemKind.WORLD }.sortedByDescending { it.addedAt }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(320.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        full { Text(t("Миры", "Worlds"), style = MaterialTheme.typography.headlineSmall) }
        full {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t("Папка миров Minecraft", "Minecraft worlds folder"), style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (tree == null) t(
                            "Выберите games/com.mojang (в Android/data/com.mojang.minecraftpe/files). На Android 11+ система может не позволить это сделать — тогда используйте «В Minecraft».",
                            "Pick games/com.mojang (inside Android/data/com.mojang.minecraftpe/files). On Android 11+ the system may refuse — then use \"To Minecraft\".",
                        ) else t("Папка подключена.", "Folder connected."),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ treePicker.launch(initial) }) { Icon(Icons.Filled.Folder, null); Spacer(Modifier.width(6.dp)); Text(if (tree == null) t("Выбрать папку", "Pick folder") else t("Сменить", "Change")) }
                        if (tree != null) {
                            OutlinedButton({ vm.refreshWorlds() }) { Icon(Icons.Filled.Refresh, null) }
                            OutlinedButton({ vm.disconnectWorlds() }) { Text(t("Отключить", "Disconnect")) }
                        }
                    }
                }
            }
        }
        full {
            Button({ importer.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text(t("Импорт мира (.mcworld)", "Import world (.mcworld)"))
            }
        }

        full { SectionTitle(t("Миры в папке игры", "Worlds in the game folder")) }
        if (worlds.isEmpty()) full { Empty(Icons.Filled.Public, if (tree == null) t("Папка не подключена", "Folder not connected") else t("Миров не найдено", "No worlds found")) }
        items(worlds, key = { it.dirName }) { w ->
            RowCard(
                title = w.name, subtitle = w.dirName,
                thumb = { UriImg(w.iconUri, Modifier.size(72.dp, 48.dp)) { Icon(Icons.Filled.Public, null, tint = MaterialTheme.colorScheme.outline) } },
            ) {
                IconButton({ export("${safeName(w.name)}.mcworld") { uri -> vm.exportWorld(w, uri) } }) { Icon(Icons.Filled.Share, t("Экспорт", "Export")) }
                IconButton({ vm.backupWorld(w) }) { Icon(Icons.Filled.Backup, t("Резервная копия", "Backup")) }
                IconButton({ toDelete = w }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }

        full { SectionTitle(t("Импортированные миры", "Imported worlds")) }
        if (libWorlds.isEmpty()) full { Empty(Icons.Filled.Public, t("Импортированных миров нет", "No imported worlds")) }
        items(libWorlds, key = { "lib_" + it.id }) { w ->
            RowCard(
                title = w.name, subtitle = "${fmtSize(w.sizeBytes)} • ${fmtDate(w.addedAt)}",
                thumb = { FileImg(vm.iconOf(w), Modifier.size(72.dp, 48.dp)) { Icon(Icons.Filled.Public, null, tint = MaterialTheme.colorScheme.outline) } },
            ) {
                IconButton({ vm.sendItem(ctx, w) }) { Icon(Icons.Filled.PlayArrow, t("В Minecraft", "To Minecraft")) }
                if (tree != null) IconButton({ vm.installWorldIntoFolder(w) }) { Icon(Icons.Filled.Folder, t("Распаковать в папку игры", "Extract to game folder")) }
                IconButton({ export("${safeName(w.name)}.mcworld") { uri -> vm.exportItem(w, uri) } }) { Icon(Icons.Filled.Share, t("Экспорт", "Export")) }
                IconButton({ toDeleteLib = w }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }

        full { SectionTitle(t("Резервные копии миров", "World backups")) }
        if (backups.isEmpty()) full { Empty(Icons.Filled.Backup, t("Резервных копий нет", "No backups")) }
        items(backups, key = { it.name }) { f ->
            RowCard(
                title = f.name.removeSuffix(".mcworld"), subtitle = "${fmtSize(f.length())} • ${fmtDate(f.lastModified())}",
                thumb = { Icon(Icons.Filled.Backup, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary) },
            ) {
                IconButton({ vm.sendToGame(ctx, f) }) { Icon(Icons.Filled.PlayArrow, t("Восстановить через Minecraft", "Restore via Minecraft")) }
                IconButton({ export(f.name) { uri -> vm.exportFile(f, uri) } }) { Icon(Icons.Filled.Share, t("Экспорт", "Export")) }
                IconButton({ toDeleteBackup = f }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }
    }

    toDelete?.let { ConfirmDialog(t("Удалить мир «${it.name}»?", "Delete world \"${it.name}\"?"), t("Мир будет удалён из папки игры безвозвратно. Сделайте резервную копию заранее.", "The world will be permanently deleted from the game folder. Back it up first."), { vm.deleteWorld(it) }) { toDelete = null } }
    toDeleteLib?.let { ConfirmDialog(t("Удалить «${it.name}»?", "Delete \"${it.name}\"?"), t("Файл будет удалён из лаунчера.", "The file will be removed from the launcher."), { vm.deleteItem(it) }) { toDeleteLib = null } }
    toDeleteBackup?.let { ConfirmDialog(t("Удалить резервную копию?", "Delete backup?"), it.name, { vm.deleteWorldBackup(it) }) { toDeleteBackup = null } }
}
