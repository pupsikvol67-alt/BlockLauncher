package com.blocklauncher.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blocklauncher.app.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    private val lib = LibraryRepository(app)
    private val builds = BuildsRepository(app, lib)
    private val worldsRepo = WorldsRepository(app, settings)

    val items = lib.items
    val buildList = builds.builds
    val busy = MutableStateFlow(false)
    val worlds = MutableStateFlow<List<WorldEntry>>(emptyList())
    val worldsError = MutableStateFlow<String?>(null)
    val worldBackups = MutableStateFlow(worldsRepo.backups())
    val buildBackups = MutableStateFlow(builds.backups())

    private val _msg = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages = _msg.asSharedFlow()
    private val cr get() = getApplication<Application>().contentResolver

    fun iconOf(i: LibItem) = lib.iconOf(i)
    fun coverOf(b: BuildPack) = builds.coverOf(b)
    fun itemsOf(b: BuildPack) = builds.itemsOf(b)
    fun fileOf(i: LibItem) = lib.fileOf(i)

    private fun tr(ru: String, en: String) = if (settings.lang.value == "en") en else ru
    private fun say(ru: String, en: String) { _msg.tryEmit(tr(ru, en)) }
    private fun errText(e: Throwable) =
        if (e is UserMessage) tr(e.ru, e.en) else tr("Ошибка: ${e.message ?: e.javaClass.simpleName}", "Error: ${e.message ?: e.javaClass.simpleName}")

    private fun task(block: suspend () -> Unit) = viewModelScope.launch {
        busy.value = true
        try { block() } catch (e: CancellationException) { throw e } catch (e: Throwable) { _msg.tryEmit(errText(e)) } finally { busy.value = false }
    }

    // ---------- Запуск / передача в Minecraft ----------
    fun play(ctx: Context) {
        if (Minecraft.version(ctx) == null) {
            say("Minecraft Bedrock не установлен — открываю Google Play", "Minecraft Bedrock is not installed — opening Google Play")
            Minecraft.openStore(ctx)
        } else Minecraft.launch(ctx).onFailure { _msg.tryEmit(errText(it)) }
    }

    fun sendToGame(ctx: Context, file: File, itemId: String? = null) {
        Minecraft.openFile(ctx, file).onSuccess {
            itemId?.let(lib::markSent)
            say("Файл передан в Minecraft — подтвердите импорт в игре", "File sent to Minecraft — confirm the import in the game")
        }.onFailure { _msg.tryEmit(errText(it)) }
    }

    fun sendItem(ctx: Context, item: LibItem) = sendToGame(ctx, lib.fileOf(item), item.id)

    // ---------- Библиотека ----------
    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        task {
            var ok = 0
            var worldsCount = 0
            val errs = mutableListOf<String>()
            for (u in uris) {
                try {
                    val i = lib.importUri(u); ok++
                    if (i.kind == ItemKind.WORLD) worldsCount++
                } catch (e: CancellationException) { throw e } catch (e: Exception) { errs += errText(e) }
            }
            if (ok > 0) say(
                "Импортировано файлов: $ok" + if (worldsCount > 0) " (миры: $worldsCount — смотрите вкладку «Миры»)" else "",
                "Imported files: $ok" + if (worldsCount > 0) " (worlds: $worldsCount — see the Worlds tab)" else "",
            )
            errs.forEach { _msg.tryEmit(it) }
        }
    }

    fun deleteItem(item: LibItem) = task {
        withContext(Dispatchers.IO) { lib.delete(item.id) }
        say("Удалено из лаунчера (в самой игре файлы не затронуты)", "Removed from the launcher (game files are untouched)")
    }

    fun exportItem(item: LibItem, uri: Uri) = task {
        withContext(Dispatchers.IO) {
            val out = cr.openOutputStream(uri) ?: throw UserMessage("Не удалось открыть место сохранения", "Could not open destination")
            out.use { lib.exportTo(item, it) }
        }
        say("Файл экспортирован", "File exported")
    }

    // ---------- Миры ----------
    private suspend fun loadWorlds() {
        if (settings.worldsTree.value == null) { worlds.value = emptyList(); worldsError.value = null; return }
        try { worlds.value = worldsRepo.list(); worldsError.value = null }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { worlds.value = emptyList(); worldsError.value = errText(e) }
    }

    fun refreshWorlds() { task { loadWorlds() } }

    fun setWorldsTree(uri: Uri) {
        try { cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
        settings.setTree(uri.toString())
        refreshWorlds()
    }

    fun disconnectWorlds() {
        settings.worldsTree.value?.let { s -> try { cr.releasePersistableUriPermission(Uri.parse(s), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {} }
        settings.setTree(null)
        worlds.value = emptyList(); worldsError.value = null
    }

    fun exportWorld(w: WorldEntry, uri: Uri) = task {
        withContext(Dispatchers.IO) {
            val out = cr.openOutputStream(uri) ?: throw UserMessage("Не удалось открыть место сохранения", "Could not open destination")
            out.use { worldsRepo.exportWorld(w, it) }
        }
        say("Мир экспортирован в .mcworld", "World exported as .mcworld")
    }

    fun backupWorld(w: WorldEntry) = task {
        val f = worldsRepo.backup(w)
        worldBackups.value = worldsRepo.backups()
        say("Резервная копия создана: ${f.name}", "Backup created: ${f.name}")
    }

    fun deleteWorld(w: WorldEntry) = task {
        val ok = withContext(Dispatchers.IO) { worldsRepo.deleteWorld(w) }
        if (ok) say("Мир удалён", "World deleted") else say("Не удалось удалить мир", "Could not delete the world")
        loadWorlds()
    }

    fun installWorldIntoFolder(item: LibItem) = task {
        val n = worldsRepo.installInto(lib.fileOf(item), item.name)
        loadWorlds()
        say("Мир распакован в папку игры ($n)", "World extracted into the game folder ($n)")
    }

    /** Резервные копии всех миров из подключённой папки (например, перед обновлением игры). */
    fun backupAllWorlds() = task {
        if (settings.worldsTree.value == null) throw UserMessage("Сначала подключите папку миров во вкладке «Миры»", "Connect the worlds folder in the Worlds tab first")
        val list = worldsRepo.list()
        if (list.isEmpty()) { say("Миров для копирования нет", "No worlds to back up"); return@task }
        for (w in list) worldsRepo.backup(w)
        worldBackups.value = worldsRepo.backups()
        say("Резервных копий создано: ${list.size}", "Backups created: ${list.size}")
    }

    fun deleteWorldBackup(f: File) { f.delete(); worldBackups.value = worldsRepo.backups() }

    fun exportFile(f: File, uri: Uri) = task {
        withContext(Dispatchers.IO) {
            val out = cr.openOutputStream(uri) ?: throw UserMessage("Не удалось открыть место сохранения", "Could not open destination")
            out.use { o -> f.inputStream().use { it.copyTo(o) } }
        }
        say("Файл экспортирован", "File exported")
    }

    // ---------- Сборки ----------
    fun saveBuild(b: BuildPack, cover: Uri?) = task { builds.upsert(b, cover); say("Сборка сохранена", "Build saved") }
    fun deleteBuild(b: BuildPack) = task { withContext(Dispatchers.IO) { builds.delete(b.id) }; say("Сборка удалена", "Build deleted") }

    fun exportBuild(b: BuildPack, uri: Uri) = task {
        withContext(Dispatchers.IO) {
            val out = cr.openOutputStream(uri) ?: throw UserMessage("Не удалось открыть место сохранения", "Could not open destination")
            out.use { builds.exportTo(b, it) }
        }
        say("Сборка экспортирована (.blockbuild)", "Build exported (.blockbuild)")
    }

    fun backupBuild(b: BuildPack) = task {
        val f = builds.backup(b)
        buildBackups.value = builds.backups()
        say("Резервная копия сборки: ${f.name}", "Build backup: ${f.name}")
    }

    fun importBuild(uri: Uri) = task { val b = builds.importUri(uri); say("Сборка «${b.name}» импортирована", "Build \"${b.name}\" imported") }

    fun restoreBuildBackup(f: File) = task { val b = builds.importFile(f); say("Восстановлено: «${b.name}»", "Restored: \"${b.name}\"") }
    fun deleteBuildBackup(f: File) { f.delete(); buildBackups.value = builds.backups() }

    // ---------- Настройки ----------
    fun clearTemp(): Long {
        val dir = getApplication<Application>().cacheDir
        val files = dir.walkBottomUp().filter { it.isFile }.toList()
        val size = files.sumOf { it.length() }
        files.forEach { it.delete() }
        say("Временные файлы очищены", "Temporary files cleared")
        return size
    }
}
