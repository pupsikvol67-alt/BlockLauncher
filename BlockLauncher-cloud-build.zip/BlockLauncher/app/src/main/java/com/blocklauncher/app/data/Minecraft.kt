package com.blocklauncher.app.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/** Единственный поддерживаемый Android способ «общаться» с Minecraft: запуск и передача файла через Intent. */
object Minecraft {
    const val PKG = "com.mojang.minecraftpe"

    fun version(ctx: Context): String? = try {
        ctx.packageManager.getPackageInfo(PKG, 0).versionName
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    private fun notInstalled() = UserMessage("Minecraft Bedrock не установлен", "Minecraft Bedrock is not installed")

    fun launch(ctx: Context): Result<Unit> = runCatching {
        val i = ctx.packageManager.getLaunchIntentForPackage(PKG) ?: throw notInstalled()
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun openStore(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    /** Страница официальной бета-программы Minecraft в Google Play. */
    fun openBeta(ctx: Context) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/apps/testing/$PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Передаёт .mcaddon/.mcpack/.mcworld в Minecraft: игра сама покажет импорт. */
    fun openFile(ctx: Context, file: File): Result<Unit> = runCatching {
        if (version(ctx) == null) throw notInstalled()
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream").setPackage(PKG)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            throw UserMessage("Minecraft не принял файл. Обновите игру или импортируйте файл вручную через «Экспорт».", "Minecraft did not accept the file. Update the game or import it manually via Export.")
        }
    }
}
