package com.blocklauncher.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemScope
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blocklauncher.app.data.Img
import com.blocklauncher.app.data.ItemKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.ceil
import kotlin.math.sin

fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024L * 1024 -> "%.1f KB".format(b / 1024.0)
    b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
    else -> "%.2f GB".format(b / 1073741824.0)
}

fun fmtDate(ms: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

@Composable
fun kindLabel(k: ItemKind): String = when (k) {
    ItemKind.ADDON -> t("Аддон", "Add-on")
    ItemKind.BEHAVIOR -> "Behavior pack"
    ItemKind.RESOURCE -> t("Ресурс-пак", "Resource pack")
    ItemKind.WORLD -> t("Мир", "World")
}

/** Полная ширина строки в сетке. */
fun LazyGridScope.full(content: @Composable LazyGridItemScope.() -> Unit) =
    item(span = { GridItemSpan(maxLineSpan) }, content = content)

@Composable
fun AsyncImg(
    key: Any?,
    modifier: Modifier = Modifier,
    pixel: Boolean = false,
    scale: ContentScale = ContentScale.Crop,
    placeholder: @Composable () -> Unit = {},
    load: suspend () -> Bitmap?,
) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, key) {
        value = withContext(Dispatchers.IO) { runCatching { load()?.asImageBitmap() }.getOrNull() }
    }
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) Image(
            bitmap = b, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = scale,
            filterQuality = if (pixel) FilterQuality.None else FilterQuality.Medium,
        ) else placeholder()
    }
}

@Composable
fun FileImg(file: File?, modifier: Modifier = Modifier, pixel: Boolean = false, placeholder: @Composable () -> Unit = {}) =
    AsyncImg(file?.let { it.path to it.lastModified() }, modifier, pixel, placeholder = placeholder) {
        file?.takeIf { it.exists() }?.let { Img.decode(it.readBytes(), 1024) }
    }

@Composable
fun UriImg(uri: Uri?, modifier: Modifier = Modifier, pixel: Boolean = false, placeholder: @Composable () -> Unit = {}) {
    val ctx = LocalContext.current
    AsyncImg(uri, modifier, pixel, placeholder = placeholder) {
        uri?.let { u -> ctx.contentResolver.openInputStream(u)?.use { Img.decode(it.readBytes(), 1024) } }
    }
}

@Composable
fun PackThumb(file: File?, size: Dp, icon: ImageVector = Icons.Filled.Extension) =
    FileImg(file, Modifier.size(size), pixel = true) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(size / 2))
    }

@Composable
fun Pill(text: String, color: Color = MaterialTheme.colorScheme.primary) {
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(color.copy(alpha = .15f), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
fun Empty(icon: ImageVector, text: String) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SectionTitle(text: String) = Text(text, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))

@Composable
fun ConfirmDialog(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(t("Удалить", "Delete"), color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("Отмена", "Cancel")) } },
    )
}

/** Карточка: миниатюра + текст, снизу ряд кнопок-действий. */
@Composable
fun RowCard(
    title: String,
    subtitle: String,
    thumb: @Composable () -> Unit,
    onClick: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val body: @Composable () -> Unit = {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                thumb()
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { actions() }
        }
    }
    if (onClick != null) Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) { body() }
    else Card(modifier = Modifier.fillMaxWidth()) { body() }
}

/** Возвращает функцию «предложить сохранить файл» (Storage Access Framework, CreateDocument). */
@Composable
fun rememberExporter(): (String, (Uri) -> Unit) -> Unit {
    var pending by remember { mutableStateOf<((Uri) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val p = pending
        pending = null
        if (uri != null) p?.invoke(uri)
    }
    return { name, cb -> pending = cb; launcher.launch(name) }
}

/** Пиксельный баннер: небо, облака и блоки земли (рисуется кодом, без картинок). */
@Composable
fun PixelBanner(modifier: Modifier = Modifier) {
    val anim = LocalAnim.current
    val t = if (anim) rememberInfiniteTransition(label = "banner")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "clouds").value else 0.2f
    val dirt = remember { listOf(Color(0xFF8B5A2B), Color(0xFF7A4C23), Color(0xFF946236), Color(0xFF6E4420)) }
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF4A90E2), Color(0xFFB9E1FF))))
        val cell = size.height / 12f
        for (i in 0..3) {
            val w = cell * 6
            val x = ((t + i * 0.27f) % 1f) * (size.width + w) - w
            val y = cell * (1.2f + (i % 3) * 1.6f)
            val c = Color.White.copy(alpha = .8f)
            drawRect(c, Offset(x, y), Size(w, cell))
            drawRect(c, Offset(x + cell, y - cell * .8f), Size(w - 2 * cell, cell))
        }
        val cols = ceil(size.width / cell).toInt()
        for (c in 0 until cols) {
            val h = (3.4f + 1.4f * sin(c * 0.55f) + 0.8f * sin(c * 1.3f)).toInt().coerceIn(2, 6)
            val top = 12 - h
            for (r in top until 12) {
                val k = (c * 31 + r * 17) % 4
                val col = when {
                    r == top -> if (k % 2 == 0) Color(0xFF5DBB3A) else Color(0xFF4FA82F)
                    r == top + 1 && k == 0 -> Color(0xFF4FA82F)
                    else -> dirt[k]
                }
                drawRect(col, Offset(c * cell, r * cell), Size(cell + 1f, cell + 1f))
            }
        }
    }
}
