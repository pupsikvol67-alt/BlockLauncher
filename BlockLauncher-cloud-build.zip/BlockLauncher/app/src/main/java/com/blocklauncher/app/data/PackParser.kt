package com.blocklauncher.app.data

import org.json.JSONObject
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * Читает .mcaddon / .mcpack / .mcworld (это обычные zip-архивы): manifest.json, иконку, имя мира.
 * Вложенные .mcpack внутри .mcaddon тоже просматриваются.
 */
object PackParser {
    class Meta {
        var name: String? = null
        var description: String? = null
        val types = mutableSetOf<String>()
        var icon: ByteArray? = null
        var levelName: String? = null
        var hasManifest = false
    }

    private class Acc {
        val meta = Meta()
        var nameDepth = 99
        var iconDepth = 99
    }

    private class NoClose(s: InputStream) : FilterInputStream(s) { override fun close() {} }

    fun parse(file: File): Meta {
        val acc = Acc()
        ZipFile(file).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                visit(e.name, e.size, 0, acc, { zf.getInputStream(e).use { it.readBytes() } }, { zf.getInputStream(e) })
            }
        }
        return acc.meta
    }

    private fun visit(path: String, size: Long, level: Int, acc: Acc, read: () -> ByteArray, open: () -> InputStream) {
        val base = path.substringAfterLast('/')
        val depth = path.count { it == '/' } + level * 3
        val small = size <= 2_000_000
        when {
            base == "manifest.json" && small -> readManifest(read(), depth, acc)
            base == "levelname.txt" && small -> acc.meta.levelName = String(read(), Charsets.UTF_8).trim().ifEmpty { null }
            (base == "pack_icon.png" || base == "world_icon.jpeg") && small && depth < acc.iconDepth -> {
                acc.meta.icon = read(); acc.iconDepth = depth
            }
            level < 2 && (base.endsWith(".mcpack", true) || base.endsWith(".zip", true)) -> scanNested(open(), level + 1, acc)
        }
    }

    private fun scanNested(input: InputStream, level: Int, acc: Acc) {
        val zin = ZipInputStream(input)
        var e = zin.nextEntry
        while (e != null) {
            if (!e.isDirectory) visit(e.name, e.size, level, acc, { zin.readBytes() }, { NoClose(zin) })
            e = zin.nextEntry
        }
    }

    private fun readManifest(bytes: ByteArray, depth: Int, acc: Acc) {
        try {
            val o = JSONObject(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
            acc.meta.hasManifest = true
            val h = o.optJSONObject("header")
            if (h != null && depth < acc.nameDepth) {
                acc.meta.name = clean(h.optString("name"))
                acc.meta.description = clean(h.optString("description"))
                acc.nameDepth = depth
            }
            o.optJSONArray("modules")?.let { arr ->
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("type")?.let { acc.meta.types.add(it.lowercase()) }
            }
        } catch (_: Exception) {
        }
    }

    /** Убирает цветовые коды «§a» и ключи локализации вида pack.name. */
    private fun clean(s: String): String? =
        s.replace(Regex("§."), "").trim().takeIf { it.isNotEmpty() && !it.startsWith("pack.") }

    fun kindOf(ext: String, meta: Meta): ItemKind = when (ext) {
        "mcworld" -> ItemKind.WORLD
        "mcaddon" -> ItemKind.ADDON
        else -> {
            val res = meta.types.any { it == "resources" || it == "skin_pack" }
            val beh = meta.types.any { it == "data" || it == "script" || it == "client_data" }
            when { res && beh -> ItemKind.ADDON; res -> ItemKind.RESOURCE; else -> ItemKind.BEHAVIOR }
        }
    }
}
