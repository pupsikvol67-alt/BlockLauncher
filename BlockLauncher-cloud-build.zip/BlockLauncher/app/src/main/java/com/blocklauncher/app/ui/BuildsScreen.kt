package com.blocklauncher.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blocklauncher.app.data.BuildPack
import com.blocklauncher.app.data.ItemKind
import com.blocklauncher.app.data.newId
import com.blocklauncher.app.data.safeName
import java.io.File

@Composable
fun BuildsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val builds by vm.buildList.collectAsStateWithLifecycle()
    val backups by vm.buildBackups.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<BuildPack?>(null) }
    var creating by remember { mutableStateOf(false) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var toDelete by remember { mutableStateOf<BuildPack?>(null) }
    var toDeleteBackup by remember { mutableStateOf<File?>(null) }

    val export = rememberExporter()
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importBuild) }
    val opened = builds.firstOrNull { it.id == openId }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(320.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        full { Text(t("Сборки", "Builds"), style = MaterialTheme.typography.headlineSmall) }
        full {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ creating = true }, Modifier.weight(1f)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text(t("Создать", "Create")) }
                OutlinedButton({ importer.launch(arrayOf("*/*")) }, Modifier.weight(1f)) { Text(t("Импорт сборки", "Import build")) }
            }
        }
        if (builds.isEmpty()) full { Empty(Icons.Filled.Inventory2, t("Сборок пока нет. Создайте первую — выберите моды и текстуры из библиотеки.", "No builds yet. Create one from your library.")) }
        items(builds, key = { it.id }) { b ->
            val n = vm.itemsOf(b).size
            RowCard(
                title = b.name, subtitle = "${t("Элементов", "Items")}: $n" + if (b.description.isNotBlank()) "\n${b.description}" else "",
                thumb = { FileImg(vm.coverOf(b), Modifier.size(72.dp, 54.dp)) { Icon(Icons.Filled.Inventory2, null, tint = MaterialTheme.colorScheme.outline) } },
                onClick = { openId = b.id },
            ) {
                IconButton({ vm.backupBuild(b) }) { Icon(Icons.Filled.Backup, t("Резервная копия", "Backup")) }
                IconButton({ export("${safeName(b.name)}.blockbuild") { uri -> vm.exportBuild(b, uri) } }) { Icon(Icons.Filled.Share, t("Экспорт", "Export")) }
                IconButton({ toDelete = b }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }
        full { SectionTitle(t("Резервные копии сборок", "Build backups")) }
        if (backups.isEmpty()) full { Empty(Icons.Filled.Backup, t("Резервных копий нет", "No backups")) }
        items(backups, key = { it.name }) { f ->
            RowCard(
                title = f.name.removeSuffix(".blockbuild"), subtitle = "${fmtSize(f.length())} • ${fmtDate(f.lastModified())}",
                thumb = { Icon(Icons.Filled.Backup, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary) },
            ) {
                IconButton({ vm.restoreBuildBackup(f) }) { Icon(Icons.Filled.Refresh, t("Восстановить", "Restore")) }
                IconButton({ export(f.name) { uri -> vm.exportFile(f, uri) } }) { Icon(Icons.Filled.Share, t("Экспорт", "Export")) }
                IconButton({ toDeleteBackup = f }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }
    }

    if (creating || editing != null) {
        BuildEditor(vm, editing, onDismiss = { creating = false; editing = null }) { b, cover ->
            vm.saveBuild(b, cover); creating = false; editing = null
        }
    }

    opened?.let { b ->
        val its = vm.itemsOf(b)
        AlertDialog(
            onDismissRequest = { openId = null },
            title = { Text(b.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FileImg(vm.coverOf(b), Modifier.fillMaxWidth().height(140.dp)) { Icon(Icons.Filled.Inventory2, null, Modifier.size(48.dp)) }
                    Text(b.description.ifBlank { t("Описание отсутствует", "No description") })
                    Text(t("Состав (по одному файлу — Minecraft импортирует файлы по очереди):", "Contents (one file at a time — Minecraft imports files in turn):"), style = MaterialTheme.typography.bodySmall)
                    if (its.isEmpty()) Text(t("Пусто", "Empty"))
                    its.forEach { it ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PackThumb(vm.iconOf(it), 36.dp, if (it.kind == ItemKind.RESOURCE) Icons.Filled.Palette else Icons.Filled.Extension)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) { Text(it.name, maxLines = 1); Text(kindLabel(it.kind), style = MaterialTheme.typography.bodySmall) }
                            IconButton({ vm.sendItem(ctx, it) }) { Icon(Icons.Filled.PlayArrow, t("В Minecraft", "To Minecraft")) }
                        }
                    }
                    OutlinedButton({ editing = b; openId = null }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp)); Text(t("Редактировать", "Edit")) }
                }
            },
            confirmButton = { TextButton({ openId = null }) { Text(t("Закрыть", "Close")) } },
        )
    }

    toDelete?.let { ConfirmDialog(t("Удалить сборку «${it.name}»?", "Delete build \"${it.name}\"?"), t("Моды и текстуры из библиотеки останутся.", "Mods and textures stay in your library."), { vm.deleteBuild(it) }) { toDelete = null } }
    toDeleteBackup?.let { ConfirmDialog(t("Удалить резервную копию?", "Delete backup?"), it.name, { vm.deleteBuildBackup(it) }) { toDeleteBackup = null } }
}

@Composable
private fun BuildEditor(vm: AppViewModel, initial: BuildPack?, onDismiss: () -> Unit, onSave: (BuildPack, Uri?) -> Unit) {
    val library by vm.items.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var sel by remember { mutableStateOf(initial?.itemIds ?: emptyList()) }
    var cover by remember { mutableStateOf<Uri?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) cover = it }
    val choices = library.filter { it.kind != ItemKind.WORLD }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) t("Новая сборка", "New build") else t("Редактирование", "Edit build")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(t("Название", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text(t("Описание", "Description")) }, minLines = 2, modifier = Modifier.fillMaxWidth())
                if (cover != null) UriImg(cover, Modifier.fillMaxWidth().height(120.dp))
                else if (initial?.hasCover == true) FileImg(vm.coverOf(initial), Modifier.fillMaxWidth().height(120.dp))
                OutlinedButton({ pick.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Image, null); Spacer(Modifier.width(6.dp)); Text(t("Выбрать обложку", "Choose cover")) }
                Text(t("Моды и текстуры (${sel.size})", "Mods & textures (${sel.size})"), style = MaterialTheme.typography.titleMedium)
                if (choices.isEmpty()) Text(t("Библиотека пуста — сначала импортируйте файлы во вкладке «Моды».", "Library is empty — import files in the Mods tab first."), style = MaterialTheme.typography.bodySmall)
                choices.forEach { it ->
                    Row(Modifier.fillMaxWidth().clickable { sel = if (it.id in sel) sel - it.id else sel + it.id }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(it.id in sel, null)
                        Spacer(Modifier.width(8.dp))
                        PackThumb(vm.iconOf(it), 32.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(it.name, maxLines = 1, modifier = Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank(),
                onClick = { onSave(BuildPack(initial?.id ?: newId(), name.trim(), desc.trim(), initial?.hasCover == true, sel, initial?.createdAt ?: System.currentTimeMillis()), cover) },
            ) { Text(t("Сохранить", "Save")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(t("Отмена", "Cancel")) } },
    )
}
