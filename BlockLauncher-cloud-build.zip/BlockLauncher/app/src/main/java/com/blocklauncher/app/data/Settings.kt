package com.blocklauncher.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 0 — как в системе, 1 — светлая, 2 — тёмная */
    val theme = MutableStateFlow(p.getInt("theme", 2))
    val lang = MutableStateFlow(p.getString("lang", null) ?: if (Locale.getDefault().language == "ru") "ru" else "en")
    val anim = MutableStateFlow(p.getBoolean("anim", true))
    val worldsTree = MutableStateFlow(p.getString("tree", null))

    fun setTheme(v: Int) { theme.value = v; p.edit().putInt("theme", v).apply() }
    fun setLang(v: String) { lang.value = v; p.edit().putString("lang", v).apply() }
    fun setAnim(v: Boolean) { anim.value = v; p.edit().putBoolean("anim", v).apply() }
    fun setTree(v: String?) { worldsTree.value = v; p.edit().putString("tree", v).apply() }
}
