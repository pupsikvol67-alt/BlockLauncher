package com.blocklauncher.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val LocalLang = compositionLocalOf { "ru" }
val LocalAnim = compositionLocalOf { true }

/** Короткая локализация: t("по-русски", "in English"). */
@Composable
fun t(ru: String, en: String): String = if (LocalLang.current == "en") en else ru

val Grass = Color(0xFF5DBB3A)
val GrassDark = Color(0xFF3F8F26)

private val Dark = darkColorScheme(
    primary = Grass, onPrimary = Color(0xFF0B1F05),
    primaryContainer = Color(0xFF2E5A1C), onPrimaryContainer = Color(0xFFC8F2B4),
    secondary = Color(0xFFC9955A), onSecondary = Color(0xFF2B1600),
    background = Color(0xFF111411), onBackground = Color(0xFFE3E8E0),
    surface = Color(0xFF111411), onSurface = Color(0xFFE3E8E0),
    surfaceVariant = Color(0xFF263024), onSurfaceVariant = Color(0xFFB4BCB0),
    surfaceContainer = Color(0xFF1A201A), surfaceContainerHigh = Color(0xFF1F261E),
    surfaceContainerHighest = Color(0xFF232A22), outline = Color(0xFF4A5748),
    error = Color(0xFFFF6B5E),
)

private val Light = lightColorScheme(
    primary = GrassDark, onPrimary = Color.White,
    primaryContainer = Color(0xFFC8F2B4), onPrimaryContainer = Color(0xFF0B2A02),
    secondary = Color(0xFF8B5A2B), onSecondary = Color.White,
    background = Color(0xFFF4F7F1), onBackground = Color(0xFF181C17),
    surface = Color(0xFFF4F7F1), onSurface = Color(0xFF181C17),
    surfaceVariant = Color(0xFFDDE5D8), onSurfaceVariant = Color(0xFF424A40),
    surfaceContainer = Color(0xFFE9EEE5), surfaceContainerHigh = Color(0xFFE3E9DF),
    surfaceContainerHighest = Color(0xFFDDE5D8), outline = Color(0xFF727B70),
    error = Color(0xFFBA1A1A),
)

private fun blockTypography(): Typography {
    val d = Typography()
    fun s(x: androidx.compose.ui.text.TextStyle) = x.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    return d.copy(
        headlineMedium = s(d.headlineMedium), headlineSmall = s(d.headlineSmall),
        titleLarge = s(d.titleLarge), titleMedium = s(d.titleMedium),
    )
}

@Composable
fun BlockTheme(dark: Boolean, lang: String, anim: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLang provides lang, LocalAnim provides anim) {
        MaterialTheme(colorScheme = if (dark) Dark else Light, typography = blockTypography(), content = content)
    }
}
