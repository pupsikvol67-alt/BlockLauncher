package com.blocklauncher.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blocklauncher.app.data.ItemKind
import com.blocklauncher.app.data.LibItem
import com.blocklauncher.app.data.safeName

private class Cat(val key: String, val ru: String, val en: String)

@Composable
fun ModsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val lib by vm.items.collectAsStateWithLifecycle()
    var sub by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableStateOf("all") }
    var selId by rememberSaveable { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<LibItem?>(null) }
    var toDelete by remember { mutableStateOf<LibItem?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }
    val export = rememberExporter()

    val cats = if (sub == 0) listOf(
        Cat("all", "Все", "All"), Cat("addon", "Аддоны", "Add-ons"),
        Cat("behavior", "Behavior packs", "Behavior packs"), Cat("sent", "Отправлены в игру", "Sent to game"),
    ) else listOf(Cat("all", "Все", "All"), Cat("sent", "Отправлены в игру", "Sent to game"))
    val activeCat = if (cats.any { it.key == cat }) cat else "all"

    val list = lib.filter { if (sub == 0) it.kind == ItemKind.ADDON || it.kind == ItemKind.BEHAVIOR else it.kind == ItemKind.RESOURCE }
        .filter {
            when (activeCat) {
                "addon" -> it.kind == ItemKind.ADDON
                "behavior" -> it.kind == ItemKind.BEHAVIOR
                "sent" -> it.sentAt > 0
                else -> true
            }
        }
        .filter { query.isBlank() || it.name.contains(query, true) || it.description.contains(query, true) }
        .sortedByDescending { it.addedAt }

    val selected = lib.firstOrNull { it.id == selId }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(320.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        full { Text(t("Моды и текстуры", "Mods & textures"), style = MaterialTheme.typography.headlineSmall) }
        full {
            TabRow(selectedTabIndex = sub, containerColor = MaterialTheme.colorScheme.background) {
                Tab(sub == 0, { sub = 0 }, text = { Text(t("Моды", "Mods")) }, icon = { Icon(Icons.Filled.Extension, null) })
                Tab(sub == 1, { sub = 1 }, text = { Text(t("Текстуры", "Textures")) }, icon = { Icon(Icons.Filled.Palette, null) })
            }
        }
        full {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, null) } },
                placeholder = { Text(t("Поиск по названию и описанию", "Search by name and description")) },
            )
        }
        full {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.forEach { c ->
                    FilterChip(selected = activeCat == c.key, onClick = { cat = c.key }, label = { Text(t(c.ru, c.en), maxLines = 1) })
                }
            }
        }
        full {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp))
                Text(t("Импорт .mcaddon / .mcpack / .mcworld", "Import .mcaddon / .mcpack / .mcworld"))
            }
        }
        full {
            Text(
                t(
                    "Включать и выключать паки нужно в настройках мира внутри Minecraft — Android не даёт лаунчеру менять это напрямую.",
                    "Enable or disable packs in the world settings inside Minecraft — Android does not let the launcher change that directly.",
                ),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (list.isEmpty()) full {
            Empty(
                if (sub == 0) Icons.Filled.Extension else Icons.Filled.Palette,
                if (lib.none { if (sub == 0) it.kind == ItemKind.ADDON || it.kind == ItemKind.BEHAVIOR else it.kind == ItemKind.RESOURCE })
                    t("Пока пусто. Импортируйте файл кнопкой выше.", "Nothing here yet. Import a file with the button above.")
                else t("Ничего не найдено", "Nothing found"),
            )
        }
        items(list, key = { it.id }) { it ->
            RowCard(
                title = it.name,
                subtitle = "${kindLabel(it.kind)} • ${fmtSize(it.sizeBytes)}" + if (it.description.isNotBlank()) "\n${it.description}" else "",
                thumb = { PackThumb(vm.iconOf(it), 64.dp, if (it.kind == ItemKind.RESOURCE) Icons.Filled.Palette else Icons.Filled.Extension) },
                onClick = { selId = it.id },
            ) {
                if (it.kind == ItemKind.RESOURCE) IconButton({ preview = it }) { Icon(Icons.Filled.Image, t("Предпросмотр", "Preview")) }
                IconButton({ vm.sendItem(ctx, it) }) { Icon(Icons.Filled.PlayArrow, t("В Minecraft", "To Minecraft")) }
                IconButton({ toDelete = it }) { Icon(Icons.Filled.Delete, t("Удалить", "Delete"), tint = MaterialTheme.colorScheme.error) }
            }
        }
    }

    selected?.let { s ->
        AlertDialog(
            onDismissRequest = { selId = null },
            title = { Text(s.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FileImg(vm.iconOf(s), Modifier.size(160.dp).align(Alignment.CenterHorizontally), pixel = true) {
                        Icon(Icons.Filled.Extension, null, Modifier.size(64.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Pill(kindLabel(s.kind)); Pill(".${s.ext}", MaterialTheme.colorScheme.secondary) }
                    Text(s.description.ifBlank { t("Описание отсутствует", "No description") })
                    Text("${fmtSize(s.sizeBytes)} • ${t("добавлен", "added")} ${fmtDate(s.addedAt)}", style = MaterialTheme.typography.bodySmall)
                    if (s.sentAt > 0) Text("${t("Передан в игру", "Sent to game")}: ${fmtDate(s.sentAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    OutlinedButton({ export("${safeName(s.name)}.${s.ext}") { uri -> vm.exportItem(s, uri) } }, Modifier.fillMaxWidth()) { Text(t("Экспорт файла", "Export file")) }
                    OutlinedButton({ toDelete = s; selId = null }, Modifier.fillMaxWidth()) { Text(t("Удалить из лаунчера", "Remove from launcher"), color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { Button({ vm.sendItem(ctx, s) }) { Text(t("В Minecraft", "To Minecraft")) } },
            dismissButton = { TextButton({ selId = null }) { Text(t("Закрыть", "Close")) } },
        )
    }

    preview?.let { p ->
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(p.name) },
            text = {
                FileImg(vm.iconOf(p), Modifier.fillMaxWidth().aspectRatio(1f), pixel = true) {
                    Text(t("В этом паке нет pack_icon.png", "This pack has no pack_icon.png"))
                }
            },
            confirmButton = { TextButton({ preview = null }) { Text(t("Закрыть", "Close")) } },
        )
    }

    toDelete?.let {
        ConfirmDialog(
            t("Удалить «${it.name}»?", "Delete \"${it.name}\"?"),
            t("Файл будет удалён из лаунчера. Уже установленное в Minecraft останется — удалить это можно только в самой игре.",
                "The file is removed from the launcher. What is already installed in Minecraft stays — remove it inside the game."),
            onConfirm = { vm.deleteItem(it) }, onDismiss = { toDelete = null },
        )
    }
}
