package com.blocklauncher.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Сборки: набор модов/текстур + название, описание, обложка. Формат файла — .blockbuild (zip). */
class BuildsRepository(private val ctx: Context, private val lib: LibraryRepository) {
    private val index = File(ctx.filesDir, "builds.json")
    private val coverDir = File(ctx.filesDir, "covers").apply { mkdirs() }
    private val backupDir = File(ctx.filesDir, "backups/builds").apply { mkdirs() }
    private val _builds = MutableStateFlow(load())
    val builds: StateFlow<List<BuildPack>> = _builds.asStateFlow()

    fun coverOf(b: BuildPack): File? = if (b.hasCover) File(coverDir, "${b.id}.jpg") else null
    fun itemsOf(b: BuildPack): List<LibItem> = b.itemIds.mapNotNull { id -> lib.items.value.firstOrNull { it.id == id } }

    private fun load(): List<BuildPack> = try {
        if (!index.exists()) emptyList() else JSONArray(index.readText()).objects().map { BuildPack.fromJson(it) }
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized
    private fun save(l: List<BuildPack>) {
        _builds.value = l
        val tmp = File(index.path + ".tmp")
        tmp.writeText(JSONArray(l.map { it.toJson() }).toString())
        tmp.renameTo(index)
    }

    suspend fun upsert(b: BuildPack, coverUri: Uri?) = withContext(Dispatchers.IO) {
        var nb = b.copy(itemIds = b.itemIds.filter { id -> lib.items.value.any { it.id == id } })
        if (coverUri != null) {
            val bytes = ctx.contentResolver.openInputStream(coverUri)?.use { it.readBytes() }
            val bmp = bytes?.let { Img.decode(it, 800) }
            if (bmp != null) {
                File(coverDir, "${b.id}.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                nb = nb.copy(hasCover = true)
            }
        }
        val cur = _builds.value
        save(if (cur.any { it.id == nb.id }) cur.map { if (it.id == nb.id) nb else it } else cur + nb)
    }

    fun delete(id: String) {
        File(coverDir, "$id.jpg").delete()
        save(_builds.value.filter { it.id != id })
    }

    fun exportTo(b: BuildPack, out: OutputStream) {
        val items = itemsOf(b)
        val meta = JSONObject().put("format", 1).put("name", b.name).put("description", b.description)
            .put("items", JSONArray(items.map { JSONObject().put("id", it.id).put("ext", it.ext) }))
        ZipOutputStream(out.buffered()).use { z ->
            z.putNextEntry(ZipEntry("build.json")); z.write(meta.toString().toByteArray()); z.closeEntry()
            coverOf(b)?.takeIf { it.exists() }?.let { c ->
                z.putNextEntry(ZipEntry("cover.jpg")); c.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
            for (item in items) {
                z.putNextEntry(ZipEntry("items/${item.fileName}"))
                lib.fileOf(item).inputStream().use { s -> s.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    suspend fun backup(b: BuildPack): File = withContext(Dispatchers.IO) {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(backupDir, "${safeName(b.name)}_$ts.blockbuild")
        f.outputStream().use { exportTo(b, it) }
        f
    }

    fun backups(): List<File> =
        backupDir.listFiles()?.filter { it.extension == "blockbuild" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    suspend fun importUri(uri: Uri): BuildPack = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, "build_${System.nanoTime()}.tmp")
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw UserMessage("Не удалось открыть файл", "Could not open file")
            input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            importFile(tmp)
        } finally {
            tmp.delete()
        }
    }

    suspend fun importFile(src: File): BuildPack = withContext(Dispatchers.IO) {
        val bad = UserMessage("Это не файл сборки BLOCK LAUNCHER (.blockbuild)", "Not a BLOCK LAUNCHER build file (.blockbuild)")
        try {
            ZipFile(src).use { zf ->
                val e = zf.getEntry("build.json") ?: throw bad
                val meta = JSONObject(zf.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) })
                val ids = mutableListOf<String>()
                val arr = meta.optJSONArray("items") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val fn = "${o.getString("id")}.${o.getString("ext")}"
                    val entry = zf.getEntry("items/$fn") ?: continue
                    val tmp = File(ctx.cacheDir, "bi_${System.nanoTime()}")
                    try {
                        zf.getInputStream(entry).use { s -> tmp.outputStream().use { s.copyTo(it) } }
                        ids += lib.importFile(tmp, fn).id
                    } catch (_: Exception) {
                    } finally {
                        tmp.delete()
                    }
                }
                val id = newId()
                var has = false
                zf.getEntry("cover.jpg")?.let { c ->
                    File(coverDir, "$id.jpg").outputStream().use { o -> zf.getInputStream(c).use { it.copyTo(o) } }
                    has = true
                }
                val b = BuildPack(id, meta.optString("name", "Build"), meta.optString("description"), has, ids, System.currentTimeMillis())
                save(_builds.value + b)
                b
            }
        } catch (e: UserMessage) {
            throw e
        } catch (e: Exception) {
            throw bad
        }
    }

    fun deleteBackup(f: File) { f.delete() }
}
