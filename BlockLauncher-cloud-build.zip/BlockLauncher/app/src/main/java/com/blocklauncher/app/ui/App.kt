package com.blocklauncher.app.ui

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun BlockLauncherApp(vm: AppViewModel) {
    val theme by vm.settings.theme.collectAsStateWithLifecycle()
    val lang by vm.settings.lang.collectAsStateWithLifecycle()
    val anim by vm.settings.anim.collectAsStateWithLifecycle()
    val dark = when (theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }

    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(dark) {
        val style = if (dark) SystemBarStyle.dark(Color.Transparent.toArgb())
        else SystemBarStyle.light(Color.Transparent.toArgb(), Color.Transparent.toArgb())
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose {}
    }

    BlockTheme(dark, lang, anim) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        val snack = remember { SnackbarHostState() }
        LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
        val busy by vm.busy.collectAsStateWithLifecycle()

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    val tabs = listOf(
                        Triple(Icons.Filled.Home, t("Главная", "Home"), 0),
                        Triple(Icons.Filled.Extension, t("Моды", "Mods"), 1),
                        Triple(Icons.Filled.Public, t("Миры", "Worlds"), 2),
                        Triple(Icons.Filled.Inventory2, t("Сборки", "Builds"), 3),
                        Triple(Icons.Filled.Settings, t("Настройки", "Settings"), 4),
                    )
                    tabs.forEach { (icon, label, i) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(label, maxLines = 1) })
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                val spec: FiniteAnimationSpec<Float> = if (anim) tween(250) else snap()
                Crossfade(tab, animationSpec = spec, label = "tab") {
                    when (it) {
                        0 -> HomeScreen(vm)
                        1 -> ModsScreen(vm)
                        2 -> WorldsScreen(vm)
                        3 -> BuildsScreen(vm)
                        else -> SettingsScreen(vm)
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}
