package com.blocklauncher.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.OutputStream

/** Собственная библиотека лаунчера: копии импортированных файлов + индекс (library.json). */
class LibraryRepository(private val ctx: Context) {
    private val root = File(ctx.filesDir, "library").apply { mkdirs() }
    private val iconDir = File(ctx.filesDir, "icons").apply { mkdirs() }
    private val indexFile = File(ctx.filesDir, "library.json")
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<LibItem>> = _items.asStateFlow()

    fun fileOf(i: LibItem) = File(root, i.fileName)
    fun iconOf(i: LibItem): File? = if (i.hasIcon) File(iconDir, i.id) else null

    private fun load(): List<LibItem> = try {
        if (!indexFile.exists()) emptyList()
        else JSONArray(indexFile.readText()).objects().map { LibItem.fromJson(it) }.filter { File(root, it.fileName).exists() }
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized
    private fun save(list: List<LibItem>) {
        _items.value = list
        val tmp = File(indexFile.path + ".tmp")
        tmp.writeText(JSONArray(list.map { it.toJson() }).toString())
        tmp.renameTo(indexFile)
    }

    fun displayName(uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    suspend fun importUri(uri: Uri): LibItem = withContext(Dispatchers.IO) {
        val name = displayName(uri)
        val tmp = File(ctx.cacheDir, "import_${System.nanoTime()}.tmp")
        try {
            val input = ctx.contentResolver.openInputStream(uri)
                ?: throw UserMessage("Не удалось открыть файл $name", "Could not open $name")
            input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            importFile(tmp, name)
        } finally {
            tmp.delete()
        }
    }

    fun importFile(src: File, displayName: String): LibItem {
        val ext = displayName.substringAfterLast('.', "").lowercase()
        if (ext !in EXTS) throw UserMessage("Формат .$ext не поддерживается. Нужны .mcaddon, .mcpack или .mcworld.", "Unsupported format .$ext. Use .mcaddon, .mcpack or .mcworld.")
        val meta = try {
            PackParser.parse(src)
        } catch (e: Exception) {
            throw UserMessage("«$displayName» повреждён или не является архивом Minecraft.", "\"$displayName\" is corrupted or not a Minecraft archive.")
        }
        if (ext != "mcworld" && !meta.hasManifest)
            throw UserMessage("В «$displayName» не найден manifest.json — это не аддон/пак Minecraft.", "No manifest.json in \"$displayName\" — not a Minecraft pack.")
        val id = newId()
        src.copyTo(File(root, "$id.$ext"), overwrite = true)
        val icon = meta.icon
        if (icon != null) File(iconDir, id).writeBytes(icon)
        val item = LibItem(
            id = id,
            kind = PackParser.kindOf(ext, meta),
            ext = ext,
            name = (if (ext == "mcworld") meta.levelName ?: meta.name else meta.name) ?: displayName.substringBeforeLast('.'),
            description = meta.description ?: "",
            hasIcon = icon != null,
            sizeBytes = src.length(),
            addedAt = System.currentTimeMillis(),
        )
        save(_items.value + item)
        return item
    }

    fun delete(id: String) {
        val it = _items.value.firstOrNull { x -> x.id == id } ?: return
        File(root, it.fileName).delete()
        File(iconDir, id).delete()
        save(_items.value.filter { x -> x.id != id })
    }

    fun markSent(id: String) = save(_items.value.map { if (it.id == id) it.copy(sentAt = System.currentTimeMillis()) else it })

    fun exportTo(item: LibItem, out: OutputStream) {
        fileOf(item).inputStream().use { it.copyTo(out) }
    }

    companion object {
        val EXTS = setOf("mcaddon", "mcpack", "mcworld")
    }
}
