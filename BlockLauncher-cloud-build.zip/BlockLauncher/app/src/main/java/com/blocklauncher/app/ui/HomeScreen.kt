package com.blocklauncher.app.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blocklauncher.app.data.ItemKind
import com.blocklauncher.app.data.Minecraft

private class News(val ruT: String, val enT: String, val ruB: String, val enB: String, val date: String)

private val NEWS = listOf(
    News(
        "BLOCK LAUNCHER 1.0", "BLOCK LAUNCHER 1.0",
        "Первый релиз: моды, текстуры, миры и сборки в одном приложении.",
        "First release: mods, textures, worlds and builds in one app.", "2026",
    ),
    News(
        "Как устанавливаются аддоны", "How add-ons are installed",
        "Лаунчер передаёт файл Minecraft штатным способом — игра сама предложит импорт. Android не разрешает приложениям писать в папки игры напрямую.",
        "The launcher hands the file to Minecraft the supported way — the game offers the import itself. Android does not let apps write into game folders directly.", "2026",
    ),
    News(
        "Доступ к папке миров", "Access to the worlds folder",
        "На Android 11+ папка Android/data закрыта для выбора. Если выбрать её нельзя — импортируйте миры через Minecraft кнопкой «В Minecraft».",
        "On Android 11+ the Android/data folder cannot be picked. If so, import worlds through Minecraft with the \"Open in Minecraft\" button.", "2026",
    ),
)

@Composable
fun HomeScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val lib by vm.items.collectAsStateWithLifecycle()
    val builds by vm.buildList.collectAsStateWithLifecycle()
    var ver by remember { mutableStateOf(Minecraft.version(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { ver = Minecraft.version(ctx) }

    val mods = lib.count { it.kind == ItemKind.ADDON || it.kind == ItemKind.BEHAVIOR }
    val textures = lib.count { it.kind == ItemKind.RESOURCE }
    val worlds = lib.count { it.kind == ItemKind.WORLD }

    var showPlay by remember { mutableStateOf(false) }
    val tree by vm.settings.worldsTree.collectAsStateWithLifecycle()

    val pulse = if (LocalAnim.current) rememberInfiniteTransition(label = "play")
        .animateFloat(1f, 1.04f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s").value else 1f

    LazyVerticalGrid(
        columns = GridCells.Adaptive(340.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        full {
            Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(20.dp))) {
                PixelBanner(Modifier.matchParentSize())
                Text(
                    "BLOCK\nLAUNCHER", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black,
                    fontSize = 32.sp, lineHeight = 34.sp,
                    style = TextStyle(shadow = Shadow(Color.Black, Offset(4f, 4f), 0f)),
                    modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
                )
            }
        }
        full {
            Button(
                onClick = { showPlay = true },
                modifier = Modifier.fillMaxWidth().height(64.dp).graphicsLayer { scaleX = pulse; scaleY = pulse },
                shape = RoundedCornerShape(12.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, null, Modifier.size(32.dp))
                Spacer(Modifier.width(8.dp))
                Text(t("ИГРАТЬ", "PLAY"), fontSize = 22.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Minecraft Bedrock", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val ok = ver != null
                        Icon(
                            if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null,
                            tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        )
                        Text(if (ok) t("Установлена версия $ver", "Installed version $ver") else t("Не установлен", "Not installed"))
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat(mods.toString(), t("Моды", "Mods"))
                    Stat(textures.toString(), t("Текстуры", "Textures"))
                    Stat(worlds.toString(), t("Миры", "Worlds"))
                    Stat(builds.size.toString(), t("Сборки", "Builds"))
                }
            }
        }
        full { SectionTitle(t("Новости лаунчера", "Launcher news")) }
        items(NEWS) { n ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(t(n.ruT, n.enT), fontWeight = FontWeight.Bold)
                    Text(t(n.ruB, n.enB), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(n.date, fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }
    if (showPlay) PlayDialog(vm, ver, tree != null) { showPlay = false }
}

@Composable
private fun PlayDialog(vm: AppViewModel, ver: String?, hasWorldsFolder: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Minecraft Bedrock") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (ver != null) t("Установленная версия: $ver", "Installed version: $ver") else t("Игра не установлена", "Game is not installed"))
                Text(
                    t("Google Play устанавливает только актуальную версию игры. Чтобы получить новую раньше других, вступите в бета-тест.",
                        "Google Play installs only the current game version. Join the beta to get new versions earlier."),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton({ Minecraft.openStore(ctx) }, Modifier.fillMaxWidth()) { Text(if (ver != null) t("Проверить обновления в Google Play", "Check for updates in Google Play") else t("Установить из Google Play", "Install from Google Play")) }
                OutlinedButton({ Minecraft.openBeta(ctx) }, Modifier.fillMaxWidth()) { Text(t("Бета-тест Minecraft", "Minecraft beta")) }
                if (hasWorldsFolder) OutlinedButton({ vm.backupAllWorlds() }, Modifier.fillMaxWidth()) { Text(t("Резервные копии всех миров", "Back up all worlds")) }
            }
        },
        confirmButton = { Button({ vm.play(ctx); onDismiss() }, enabled = ver != null) { Icon(Icons.Filled.PlayArrow, null); Text(t("Запустить", "Launch")) } },
        dismissButton = { TextButton(onDismiss) { Text(t("Закрыть", "Close")) } },
    )
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
