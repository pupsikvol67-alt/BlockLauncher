package com.blocklauncher.app.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class WorldEntry(val dirName: String, val name: String, val dir: DocumentFile, val iconUri: Uri?)

/**
 * Работа с папкой minecraftWorlds через Storage Access Framework.
 * Android 11+ часто не даёт выбрать Android/data — тогда пользуйтесь импортом через Minecraft.
 */
class WorldsRepository(private val ctx: Context, private val settings: Settings) {
    private val backupDir = File(ctx.filesDir, "backups/worlds").apply { mkdirs() }

    private fun noAccess() = UserMessage(
        "Папка миров не подключена или недоступна. Выберите папку games/com.mojang (или minecraftWorlds).",
        "Worlds folder is not connected or not accessible. Pick games/com.mojang (or minecraftWorlds).",
    )

    fun resolveWorldsDir(): DocumentFile? {
        val uri = settings.worldsTree.value ?: return null
        val root = DocumentFile.fromTreeUri(ctx, Uri.parse(uri)) ?: return null
        if (!root.exists() || !root.canRead()) return null
        if (root.name == "minecraftWorlds") return root
        root.findFile("minecraftWorlds")?.let { return it }
        root.findFile("com.mojang")?.findFile("minecraftWorlds")?.let { return it }
        root.findFile("games")?.findFile("com.mojang")?.findFile("minecraftWorlds")?.let { return it }
        root.findFile("files")?.findFile("games")?.findFile("com.mojang")?.findFile("minecraftWorlds")?.let { return it }
        return null
    }

    suspend fun list(): List<WorldEntry> = withContext(Dispatchers.IO) {
        val dir = resolveWorldsDir() ?: throw noAccess()
        dir.listFiles().filter { it.isDirectory }.mapNotNull { d ->
            runCatching {
                val kids = d.listFiles()
                if (kids.none { it.name == "level.dat" }) return@runCatching null
                val name = kids.firstOrNull { it.name == "levelname.txt" }?.let { f ->
                    ctx.contentResolver.openInputStream(f.uri)?.use { it.readBytes().toString(Charsets.UTF_8).trim() }
                }?.ifEmpty { null } ?: d.name ?: "World"
                WorldEntry(d.name ?: "", name, d, kids.firstOrNull { it.name == "world_icon.jpeg" }?.uri)
            }.getOrNull()
        }.sortedBy { it.name.lowercase() }
    }

    private fun zipTree(dir: DocumentFile, z: ZipOutputStream, prefix: String) {
        for (f in dir.listFiles()) {
            val n = prefix + (f.name ?: continue)
            if (f.isDirectory) zipTree(f, z, "$n/")
            else {
                z.putNextEntry(ZipEntry(n))
                ctx.contentResolver.openInputStream(f.uri)?.use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    fun exportWorld(w: WorldEntry, out: OutputStream) {
        ZipOutputStream(out.buffered()).use { zipTree(w.dir, it, "") }
    }

    suspend fun backup(w: WorldEntry): File = withContext(Dispatchers.IO) {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(backupDir, "${safeName(w.name)}_$ts.mcworld")
        try {
            f.outputStream().use { exportWorld(w, it) }
        } catch (e: Exception) {
            f.delete(); throw e
        }
        f
    }

    fun backups(): List<File> =
        backupDir.listFiles()?.filter { it.extension == "mcworld" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun deleteWorld(w: WorldEntry): Boolean = w.dir.delete()

    /** Распаковывает .mcworld прямо в папку minecraftWorlds. */
    suspend fun installInto(file: File, displayName: String): String = withContext(Dispatchers.IO) {
        val dir = resolveWorldsDir() ?: throw noAccess()
        val base = "BL_" + safeName(displayName).replace(' ', '_')
        var n = base
        var i = 1
        while (dir.findFile(n) != null) n = "${base}_${i++}"
        val target = dir.createDirectory(n) ?: throw noAccess()
        val dirs = HashMap<String, DocumentFile>().apply { put("", target) }
        ZipFile(file).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                val parts = e.name.split('/').filter { it.isNotEmpty() }
                if (parts.isEmpty() || parts.any { it == ".." }) continue
                var path = ""
                var cur = target
                for (p in parts.dropLast(1)) {
                    path = if (path.isEmpty()) p else "$path/$p"
                    cur = dirs.getOrPut(path) { cur.createDirectory(p) ?: throw noAccess() }
                }
                val out = cur.createFile("application/octet-stream", parts.last()) ?: throw noAccess()
                ctx.contentResolver.openOutputStream(out.uri)?.use { o -> zf.getInputStream(e).use { it.copyTo(o) } }
            }
        }
        n
    }
}
