package com.blocklauncher.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blocklauncher.app.data.Minecraft
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val theme by vm.settings.theme.collectAsStateWithLifecycle()
    val lang by vm.settings.lang.collectAsStateWithLifecycle()
    val anim by vm.settings.anim.collectAsStateWithLifecycle()
    var cache by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        cache = withContext(Dispatchers.IO) { ctx.cacheDir.walkBottomUp().filter { it.isFile }.sumOf { f -> f.length() } }
    }
    val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0" }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(340.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        full { Text(t("Настройки", "Settings"), style = MaterialTheme.typography.headlineSmall) }
        item {
            SettingCard(Icons.Filled.Palette, t("Тема", "Theme")) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(theme == 2, { vm.settings.setTheme(2) }, label = { Text(t("Тёмная", "Dark")) })
                    FilterChip(theme == 1, { vm.settings.setTheme(1) }, label = { Text(t("Светлая", "Light")) })
                    FilterChip(theme == 0, { vm.settings.setTheme(0) }, label = { Text(t("Системная", "System")) })
                }
            }
        }
        item {
            SettingCard(Icons.Filled.Language, t("Язык приложения", "App language")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(lang == "ru", { vm.settings.setLang("ru") }, label = { Text("Русский") })
                    FilterChip(lang == "en", { vm.settings.setLang("en") }, label = { Text("English") })
                }
            }
        }
        item {
            SettingCard(Icons.Filled.Tune, t("Анимации", "Animations")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t("Баннер, кнопка «Играть», переходы", "Banner, Play button, transitions"), Modifier.weight(1f))
                    Switch(anim, { vm.settings.setAnim(it) })
                }
            }
        }
        item {
            SettingCard(Icons.Filled.CleaningServices, t("Временные файлы", "Temporary files")) {
                Text("${t("Занято", "Used")}: ${fmtSize(cache)}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton({ vm.clearTemp(); cache = 0L }) { Text(t("Очистить", "Clear")) }
            }
        }
        full {
            SettingCard(Icons.Filled.Info, t("О лаунчере", "About")) {
                Text("BLOCK LAUNCHER $ver")
                Text(
                    t("Неофициальный лаунчер для Minecraft Bedrock Edition. Не связан с Mojang и Microsoft. Не изменяет игру и не обходит лицензирование: Minecraft нужно купить отдельно.",
                        "Unofficial launcher for Minecraft Bedrock Edition. Not affiliated with Mojang or Microsoft. It does not modify the game or bypass licensing: Minecraft must be purchased separately."),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("Minecraft: ${Minecraft.version(ctx) ?: t("не установлен", "not installed")}", style = MaterialTheme.typography.bodySmall)
                Text("Android API ${android.os.Build.VERSION.SDK_INT}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SettingCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}
